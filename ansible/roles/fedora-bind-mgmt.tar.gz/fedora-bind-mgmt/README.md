fedora-bind-mgmt
=========

This role is for configuring the BIND9 DNS VM for the nested-openshift-sandbox labs. 

Requirements
------------

Role Variables
--------------

defaults/main.yml:

|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`bind_server_ip`|String|192.168.122.2|IP of the DNS server VM on the default libvirt network|
|`base_domain`|String|lab.example.com|Base domain used in the nested OpenShift sandbox labs|
|`ocp_domain`|String|ocp|Domain prepended to the base_domain for OpenShift|
|`public_forwarder_ip_0`|String|8.8.8.8|IP of first DNS forwarder for external resolution|
|`public_forwarder_ip_1`|String|8.8.4.4|IP of second DNS forwarder for external resolution|

Dependencies
------------

None.

Example Playbook
----------------

- name: Install named and configure the zones
  hosts: dns_server
  become: true
  roles:
    - fedora-bind-mgmt

License
-------

GPL-3.0-only

Author Information
------------------

Tim Darnell
