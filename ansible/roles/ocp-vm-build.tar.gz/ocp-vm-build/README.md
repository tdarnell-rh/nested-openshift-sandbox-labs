ocp-vm-build Role
=========

This role deploys a SNO (Single Node OpenShift), TNA (Two Node Arbiter), or a compact 3-node OpenShift cluster via the Agent-based Installer (ABI) onto a libvirt-based hypervisor machine managed by Ansible. The OCP deployment platform is 'none' for SNO and 'baremetal' for TNA/compact in case additional nodes are desired to be deployed at a later time to allow for flexibility.

Originally developed for me to learn Ansible (better) as well as to deploy an OpenShift cluster that I can take with me on my laptop without relying on homelab, datacenter, or public cloud resources.

### Storage Details
Nodes have a couple of additional drives to test various software-defined storage solutions such as Portworx and ODF, and use the NVMe disk definition support provided in libvirt to enable NVMe disk identification within CoreOS for the additional disks. The root disk is defined as a virtio disk for each node, and only the additional disks are defined as NVMe devices.

In the TNA configuration, the arbiter only has one additional NVMe drive to support the Portworx TNA configuration where the arbiter needs to host a 3rd instance of the ETCD database for the Portworx StorageCluster resource.

In the SNO configuration, the SNO node has one additional NVMe drive to use for the LVM operator or local path provisioner to provide persistent storage to the SNO node.

### Network Details
Nodes are configured with a single virtual NIC that is added to bond0 within the CoreOS deployment. See templates/sno.xml.j2, templates/vmworker.xml.j2, templates/vm_arbiter.xml.j2, and templates/ocp-{sno,tna,compact}-agent-config.yaml.j2 for details.

This was done in order to allow simulation of network configurations on the cluster typically seen in bare metal OCP deployments instead of single NIC deployments.

### Memory Optimization
I was able to reduce the memory used by the OCP nodes by enabling KSM (https://docs.kernel.org/admin-guide/mm/ksm.html) on the target libvirt host. If you are struggling with the memory requirements for multiple SNO clusters or a TNA or compact cluster, look into using KSM and ksmtuned to squeeze out a little extra memory savings (at the expense of a bit more CPU usage).

### Accessing Deployed Cluster
The role copies the following to a directory on the ansible node defined by the "local_auth_folder" variable:  
  - kubeconfig
  - kubeadmin password
  - openshift-installer log file
  - original agent-config.yaml file
  - original install-config.yaml file

Within the directory defined by "local_auth_folder", you will see a directory with the libvirt machine name and the above files are located in the directory structure there (look for the "installer" directory that corresponds to your cluster name and cluster type). Note that the openshift-installer log file is ".openshift-installer.log". To find your console URL, you will need to tail this log file and you should see your login information and console URL within the last 5 lines or so. The original agent-config and install-config YAML files are also located in the "installer-backup" directory for future reference since the installer deletes the original files once the install begins.

### Role Workflow and Associated Task Files
1. **Pre-flight/Config Checks (pre_flight.yml, config_checks.yml):**  
    - Check package requirements on libvirt host
    - Verifies proper forward/reverse DNS lookup records exist and are resolvable
    - Checks for conflicting, existing VM names on libvirt host
    - Verifies pull secret, ssh key, and local folder to hold auth info exist

2. **Create disks for OCP node VMS (create_nvme.yml):**  
    - Create virtio root disk (qcow2) and NVMe disk (raw img) files for each node
    - Set permissions and selinux context for disk files

3. **Create VMs (create_sno_vms.yml, create_compact_vms.yml, create_tna_vms.yml):**  
    - Create the compact or TNA VMs depending on what OCP deployment type has been requested

4. **Create the OpenShift agent-config and install-config (create_sno_ocp_yaml.yml, create_compact_ocp_yaml.yml, create_tna_ocp_yaml.yml):**  
    - Obtain the MAC addresses from the newly created VMs
    - Create the agent-config from the templates ocp-{sno,compact,tna}-agent-config.yaml.j2
    - Create the install-config from the templates ocp-{sno,compact,tna}-install-config.yaml.j2

5. **Prep the openshift-installer and generate the ISO (ocp_pre_installer_tasks.yml):**  
    - Create installer and installer-backup directories
    - Copy the agent-config and install-config files to the installer-backup directory
    - Move the agent-config and install-config files to the installer directory
    - Download and extract the installer for the OCP version requested
    - Generate the installer ISO
    - Move the installer ISO to the libvirt ISO image directory and set proper permissions and selinux context

6. **Mount the install ISO to the libvirt VMs and start the VMs (start_ocp_install.yml)**

7. **Monitor the installation progress (check_ocp_install.yml):**  
    - Execute the installer agent wait-for bootstrap-complete so we are capturing bootstrap progress in the .openshift_install.log
    - Wait for "Bootstrap is complete" msg in installer log
    - Execute the installer agent wait-for install-complete so we are capturing install progress in the .openshift_install.log
    - Wait for "Install complete" msg in installer log
    - Fetch the installer log to the "local_auth_folder"
    - Fetch kubeconfig and kubeadmin password to the "local_auth_folder"
    - Fetch original agent-config and install-config to the "local_auth_folder"
    - Cleanup the install and tmp directories on the libvirt host

Requirements
------------
**Hardware:** Developed on a 21KWS Lenovo with an Intel Core Ultra 7 165H, 64GB RAM, and 1TB NVMe drive. Anything equivalent or higher should work fine, more RAM would be beneficial. Not tested on Mac or ARM.

**Software (target machine running VMs):**      
  - OS: Fedora 43 recommended (for libvirt requirements)
  - Virt: libvirt >= 11.6 (for virtual NVMe disk support)

**Software (ansible node):**    
  - Ansible: core 2.16.14
    - Collections:
      - community.libvirt >= 2.0.0
      - community.general >= 12.0.1
      - ansible.utils >= 6.0.0
      - ansible.builtin >= 2.16.14

**DNS:**    
  - Forward and reverse lookup records resolvable by the "ocp_dns_ip" DNS server for:
    - All nodes
    - OpenShift API
  - Forward lookup record for *.apps to support the default route/ingress
  - These records must be resolvable by the ansible node running the playbook; if they are not, the role will fail during pre-flight checks

**Existing VMs:**    
  - Node names need to be unique on the libvirt target. The role will check existing VMs on the libvirt host and exit during pre-flight checks if conflicting names exist.

**Libvirt Networking:**    
  - The "vm_net" variable that defines the libvirt network which the VM nodes attach to should have Internet access either directly or via NAT
  - This role only supports static IP assignment of the nodes. If your libvirt network has a DHCP range, please select IP addresses for the nodes, OCP API, and wildcard *.apps route that are outside of your DHCP range.  
  - Please note that for the SNO configuration, the 'ocp_api_ip' and 'ocp_ingress_ip' variables need to match the IP address of your SNO node ('sno_node_0_ip').

**SELinux:**    
  - This role was developed on a system with SELinux enforcing. All disk image creations, etc... will have the appropriate SELinux file contexts set to properly allow execution of the VMs.

Role Variables
--------------

defaults/main.yml:

### VM/libvirt Info
|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`libvirt_images_dir`|String|/var/lib/libvirt/images|Directory on the libvirt host to store root and NVMe disk images for the nodes|
|`libvirt_isos_dir`|String|/var/lib/libvirt/isos|Directory on the libvirt host to store the ISO image used to boot OCP nodes|
|`vm_net`|String|default|Libvirt network to connect the VM nodes to on the libvirt host|
|`qemu_user`|String|qemu|User on the libvirt system that should own the disk and ISO images|
|`qemu_group`|String|qemu|Group on the libvirt system that should own the disk and ISO images|
|`machine_type`|String|bios|Machine type for VMs deployed (either `bios` or `uefi`)|

  ### OCP Information
|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`ocp_version`|String|4.20.3|X.Y.Z version of OCP, used to build URL string for installer download|
|`ocp_type`|String|compact|Type of cluster to deploy. Either "sno" for Single Node OpenShift, "tna" for Two Node Arbiter, or "compact" for compact 3-node cluster|
|`ocp_bootstrap_timeout`|String|60|Number of minutes we wait for the installer to reach "Bootstrap complete" status|
|`ocp_install_timeout`|String|40|Number of minutes we wait for the installer to reach "Install complete" status|
|`ocp_cluster_prefix`|String|420|OCP cluster name that is prepended to the OCP cluster domain|
|`ocp_domain`|String|ocp.example.com|Base FQDN for the OCP cluster|
|`ocp_cluster_cidr`|String|10.128.0.0/14|Cluster CIDR used for the OCP cluster|
|`ocp_cluster_host_prefix`|String|23|Cluster host CIDR prefix carved from the OCP cluster CIDR|
|`ocp_machine_cidr`|String|192.168.122.0/24|Machine/node CIDR used for the OCP cluster|
|`ocp_service_cidr`|String|172.30.0.0/16|Service CIDR used for the OCP cluster|
|`ocp_api_ip`|String|192.168.122.23|IP address for the OpenShift API|
|`ocp_ingress_ip`|String|192.168.122.24|IP address for the wildcard route/ingress|
|`ocp_dns_ip`|String|192.168.122.2|IP address of the forwarding DNS server node clients should use which can resolve necessary node and api forward/reverse records, and the wildcard *.apps forward record|
|`ocp_gateway_ip`|String|192.168.122.1|Default route for the machine CIDR|
|`ocp_pull_secret`|String|''|Your OpenShift pull secret from https://console.redhat.com. I created an ansible vault for this and my ssh public key, and used 'vars_files' in the calling playbook to keep this sensitive info private. I suggest you do the same. Please use single quotes to contain your pull secret.|
|`ocp_ssh_ip`|String|""|The SSH public key you want to be able to connect to the OCP nodes with|
|`local_auth_folder`|String|/home/ansible-user|The directory on the Ansible node running the playbook that will contain your resultant cluster auth info and openshift-installer log file|

### SNO Node Info
|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`sno_worker_node_name`|String|- ocp-0-sno|A list of one node name (short) for the single node in the SNO cluster|
|`sno_node_0_ip`|String|192.168.122.40|IP address within the OCP machine CIDR range for the SNO node|
|`sno_node_prefix_length`|String|24|CIDR subnet prefix for the machine CIDR range|
  
### SNO Node Resource Definitions
|Variable|Type|Default|Minimum|Description|
|:---|:---|:---|:---|:---|
|`vm_sno_worker_vcpus`|String|8|8|Number of vCPUs configured for the SNO node|
|`vm_sno_worker_mem_mb`|String|18432|18432|MB of memory configured for the SNO node - (See: https://issues.redhat.com/browse/OCPBUGS-62790)|
|`vm_sno_worker_root_size_mb`|String|122280|122280|Size of root disk for the SNO node (MB)|
|`vm_sno_worker_data1_size_mb`|String|65535|1|Size of the additional NVMe drive for the SNO node (MB)|


### Two Node Arbiter Node Info
|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`tna_worker_node_names`|String|- ocp-0-tna<br/>- ocp-1-tna|A list of two node names (short) for the control plane/worker nodes in the TNA cluster|
|`tna_arbiter_node_name`|String|- arbiter-tna|A list of a single node name (short) for the arbiter node in the TNA cluster|
|`tna_node_0_ip`|String|192.168.122.30|IP address within the OCP machine CIDR range for node 0 in the TNA cluster|
|`tna_node_1_ip`|String|192.168.122.31|IP address within the OCP machine CIDR range for node 1 in the TNA cluster|
|`tna_node_arbiter_ip`|String|192.168.122.32|IP address within the OCP machine CIDR range for the arbiter node in the TNA cluster|
|`tna_node_prefix_length`|String|24|CIDR subnet prefix for the machine CIDR range|

### TNA Node Resource Definitions
|Variable|Type|Default|Minimum|Description|
|:---|:---|:---|:---|:---|
|`vm_tna_worker_vcpus`|String|8|8|Number of vCPUs configured for node 0 and node 1 in the TNA cluster|
|`vm_tna_worker_mem_mb`|String|18432|18432|MB of memory configured for node 0 and node 1 in the TNA cluster - (See: https://issues.redhat.com/browse/OCPBUGS-62790)|
|`vm_tna_arbiter_vcpus`|String|8|8|Number of vCPUs configured for arbiter node in the TNA cluster|
|`vm_tna_arbiter_mem_mb`|String|8192|8192|MB of memory configured for arbiter node in the TNA cluster|
|`vm_tna_worker_root_size_mb`|String|122280|122280|Size of root disk for node 0 and node 1 in the TNA cluster (MB)|
|`vm_tna_worker_data1_size_mb`|String|65535|1|Size of the additional first NVMe drive for node 0 and node 1 in the TNA cluster (MB)|
|`vm_tna_worker_data2_size_mb`|String|40960|1|Size of the additional second NVMe drive for node 0 and node 1 in the TNA cluster (MB)|
|`vm_tna_arbiter_root_size_mb`|String|122280|122280|Size of root disk for arbiter node in the TNA cluster (MB)|
|`vm_tna_arbiter_data1_size_mb`|String|65535|1|Size of the single additional NVMe drive for arbiter node in the TNA cluster (MB)|


### Compact Cluster Node Info
|Variable|Type|Default|Description|
|:---|:---|:---|:---|
|`compact_node_names`|String|- ocp-0<br/>- ocp-1<br/>- ocp-2|A list of three node names (short) for the control plane/worker nodes in the compact cluster|
|`compact_node_0_ip`|String|192.168.122.20|IP address within the OCP machine CIDR range for node 0 in the compact cluster|
|`compact_node_1_ip`|String|192.168.122.21|IP address within the OCP machine CIDR range for node 1 in the compact cluster|
|`compact_node_2_ip`|String|192.168.122.22|IP address within the OCP machine CIDR range for node 2 in the compact cluster|
|`compact_node_prefix_length`|String|24|CIDR subnet prefix for the machine CIDR range|

### Compact Node Resource Definitions
|Variable|Type|Default|Minimum|Description|
|:---|:---|:---|:---|:---|
|`vm_compact_worker_vcpus`|String|8|8|Number of vCPUs configured for node 0, 1, and 2 in the compact cluster|
|`vm_compact_worker_mem_mb`|String|18432|18432|MB of memory configured for node 0, 1, and 2 in the compact cluster - (See: https://issues.redhat.com/browse/OCPBUGS-62790)|
|`vm_compact_worker_root_size_mb`|String|122280|122280|Size of root disk for node 0, 1, and 2 in the compact cluster (MB)|
|`vm_compact_worker_data1_size_mb`|String|65535|1|Size of the additional first NVMe drive for node 0, 1, and 2 in the compact cluster (MB)|
|`vm_compact_worker_data2_size_mb`|String|40960|1|Size of the additional second NVMe drive for node 0, 1, and 2 in the compact cluster (MB)|


Dependencies
------------

  - None, other than listed in requirements section.

Example Playbook
----------------

Example below stores sensitive info variables (ocp_pull_secret and ocp_ssh_key) in an Ansible vault file (sens_vars.yml) and includes them using "vars_files": 
```
- name: Install OCP as libvirt VMs
  hosts: libvirt-target
  become: true
  vars_files:
    - sens_vars.yml
  roles:
    - ocp-vm-build
```
License
-------

BSD

Author Information
------------------

Tim Darnell
